settings.js doldurup intentleri açın sorunsuz çalışıyor kuramayan olursa siktirsin gitsin kullanmasın bana ulaşmayın aq
