module.exports = {
    bot: {
        botOwner: [""],
        botToken: "",
        botPrefix: "",
        botStatus: "Cross ❤️ Serendia"


    },
    guild: {
        id: "",
        tag: "",
        unTag: "•"
    },

    roles: {
        manRoles: [],
        womanRoles: [],
        unregisterRoles: [],
        registerStaff: "",
        Suspecious: "",
        vipRole: "",
        boosterRole: "",
        botCommands: "",
        tagRole: ""
    },
    channel: {
        rules: "",
        botVoice: "",
        registerChat: ""
    },
    emojis: {
        yes: "",
        no: "",
        man: "", // erkek ve kız emoji ıd
        woman: ""
    }
};
